/*
search.js
*/
// Module search yet to be developed
function findSearch(){
	var key = prompt("Enter your query","");
	msg("No results found for "+key);
}
