## Panda WebOS -  [![GitHub stars](https://img.shields.io/github/stars/aniketchaudhari3/pegasus-os)](https://github.com/aniketchaudhari3/aniketchaudhari3/pegasus-os)
An awesome operating system simulator written in pure JavaScript. 

You can try demo on [website](https://pegasus-os.netlify.app)

[Contact](https://instagram.com/aniket.chaudhari3)


[Personal Website](https://aniketchaudhari.com)


[Watch on YouTube](https://youtu.be/5xMvzAlqb28)
